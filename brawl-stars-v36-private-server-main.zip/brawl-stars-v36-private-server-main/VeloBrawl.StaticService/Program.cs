﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.StaticService;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd,
            "Emulation of 'StaticService' has been launched.");
    }
}
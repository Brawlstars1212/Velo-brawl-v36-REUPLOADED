﻿namespace VeloBrawl.StaticService.Laser;

public static class GlobalStaticCloud
{
    public static string? PragmaAndServerEnvironment { get; set; }
}
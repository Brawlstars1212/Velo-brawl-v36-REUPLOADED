﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.Tools;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'Tools' has been launched.");
    }
}
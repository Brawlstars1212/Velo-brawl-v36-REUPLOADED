﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.Titan;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'Titan' has been launched.");
    }
}
﻿namespace VeloBrawl.Titan.Mathematical.Pull;

public abstract class Elf32_Rel
{
    public abstract uint rOffset { get; set; }
    public abstract uint rInfo { get; set; }
}
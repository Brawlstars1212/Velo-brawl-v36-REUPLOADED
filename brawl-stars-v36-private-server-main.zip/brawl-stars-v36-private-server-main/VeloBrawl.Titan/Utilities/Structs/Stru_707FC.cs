﻿using VeloBrawl.Titan.Mathematical.Pull;

namespace VeloBrawl.Titan.Utilities.Structs;

public class Stru707Fc : Elf32_Rel
{
    public override uint rOffset { get; set; } = 12575860u;
    public override uint rInfo { get; set; } = 23u;
}
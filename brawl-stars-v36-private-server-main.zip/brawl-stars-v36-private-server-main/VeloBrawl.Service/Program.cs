﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.Service;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'Service' has been launched.");
    }
}
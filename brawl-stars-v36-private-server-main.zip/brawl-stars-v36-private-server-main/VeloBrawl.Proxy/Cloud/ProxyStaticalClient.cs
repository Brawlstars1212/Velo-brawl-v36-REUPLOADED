﻿using VeloBrawl.Proxy.Network;

namespace VeloBrawl.Proxy.Cloud;

public static class ProxyStaticalClient
{
    public static ProxySocketTransportClient ProxySocketTransportClient = null!;
}
﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.Proxy;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'Proxy' has been launched.");
    }
}
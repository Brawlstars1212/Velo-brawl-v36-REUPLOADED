﻿namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Alliance;

public class AllianceMemberItem
{
    // todo.
}
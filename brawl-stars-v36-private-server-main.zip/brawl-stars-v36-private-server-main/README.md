# brawl-stars-v36-private-server
the best v36 brawl stars open source private server.

# client
you must create client by yourself.

# screenshots #
![v36](https://raw.githubusercontent.com/XidMods05/brawl-stars-v36-private-server/main/Screenshots/menu.png)
![v36](https://raw.githubusercontent.com/XidMods05/brawl-stars-v36-private-server/main/Screenshots/battle.png)
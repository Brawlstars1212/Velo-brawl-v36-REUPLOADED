﻿namespace VeloBrawl.Supercell.Titan.CommonUtils.Utils;

public enum ShopPriceTypeHelperTable
{
    ByGems = 0,
    ByGold = 1,
    ForWatch = 2,
    ByStarPoints = 3,
    NotCanBought = 4
}
﻿namespace VeloBrawl.Supercell.Titan.CommonUtils.Utils;

public enum JsonNodeTypeHelperTable
{
    Array = 1,
    Object,
    Number,
    String,
    Boolean,
    Null
}
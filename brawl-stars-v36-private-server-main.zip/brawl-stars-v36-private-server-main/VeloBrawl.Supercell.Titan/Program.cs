﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.Supercell.Titan;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd,
            "Emulation of 'Supercell::Titan' has been launched.");
    }
}
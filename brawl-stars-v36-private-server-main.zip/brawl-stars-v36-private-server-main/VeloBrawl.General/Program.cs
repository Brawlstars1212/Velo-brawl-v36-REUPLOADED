﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.General;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'General' has been launched.");
    }
}
﻿namespace VeloBrawl.General.NetIsland.LaserBattle.Significant.Attack;

public class LogicAttackSpecialParams
{
    // todo.
}
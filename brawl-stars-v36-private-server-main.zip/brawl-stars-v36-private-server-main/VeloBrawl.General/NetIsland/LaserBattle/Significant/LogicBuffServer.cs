﻿namespace VeloBrawl.General.NetIsland.LaserBattle.Significant;

public class LogicBuffServer
{
    // todo.
}
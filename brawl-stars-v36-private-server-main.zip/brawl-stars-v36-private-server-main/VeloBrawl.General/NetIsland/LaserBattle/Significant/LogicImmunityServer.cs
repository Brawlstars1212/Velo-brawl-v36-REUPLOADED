﻿namespace VeloBrawl.General.NetIsland.LaserBattle.Significant;

public class LogicImmunityServer
{
    // todo.
}
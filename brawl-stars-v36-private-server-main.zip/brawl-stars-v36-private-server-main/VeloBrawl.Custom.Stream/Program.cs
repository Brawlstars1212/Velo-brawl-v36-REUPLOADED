﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.Custom.Stream;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd,
            "Emulation of 'Custom::Stream' has been launched.");
    }
}
﻿using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.Manage;

public static class Program
{
    public static void Main(string[] args)
    {
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Cmd, "Emulation of 'Manage' has been launched.");
    }
}